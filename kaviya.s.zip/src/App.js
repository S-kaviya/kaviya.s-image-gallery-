import './App.css';
import { SRLWrapper } from "simple-react-lightbox";
import img1 from './images/img1.jpeg';
import img2 from './images/img2.jpeg';
import img3 from './images/img3.jpeg';
import img4 from './images/img4.jpeg';
import img5 from './images/img5.jpeg';
import img6 from './images/img6.jpeg';
import img7 from './images/img7.jpeg';
import img8 from './images/img8.jpeg';
import img9 from './images/img9.jpeg';
import img10 from './images/img10.jpeg';
import img11 from './images/img11.jpeg';
import img12 from './images/img12.jpeg';
import img13 from './images/img13.jpeg';
import img14 from './images/img14.jpeg';

function Gallery()
{
    let data=[
        {
          id:1,
          imgSrc:img1,
        },
        {
          id:2,
          imgSrc:img2,
        },
        {
          id:3,
          imgSrc:img3,
        },
        {
          id:4,
          imgSrc:img4,
        },
        {
          id:5,
          imgSrc:img5,
        },
        {
          id:6,
          imgSrc:img6,
        },
        {
          id:7,
          imgSrc:img7,
        },
        {
          id:8,
          imgSrc:img8,
        },
        {
          id:9,
          imgSrc:img9,
        },
        {
          id:10,
          imgSrc:img10,
        },
        {
          id:11,
          imgSrc:img11,
        },
        {
          id:12,
          imgSrc:img12,
        },
        {
          id:13,
          imgSrc:img13,
        },
        {
          id:14,
          imgSrc:img14,
        }
    ]
    return(
      <SRLWrapper>
        <div className="container">
            {data.map((item)=>{
                return (
                  <div className='image-card'>
                    <a href="item.imgSrc">
                        <img className='image' src={item.imgSrc} style={{width:'60%'}}/>
                    </a>
                  </div>
                )
            })}
  
        </div>
        </SRLWrapper>
        );
}

export default Gallery;